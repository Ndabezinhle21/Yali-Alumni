package com.digiplay.yalizimalumni.ui.home;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.digiplay.yalizimalumni.FirebaseViewHold;
import com.digiplay.yalizimalumni.Main2Activity;
import com.digiplay.yalizimalumni.Model;
import com.digiplay.yalizimalumni.R;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

import java.util.ArrayList;

public class HomeFragment extends Fragment {
    private RecyclerView recyclerView;
    private ArrayList<Model> arrayList;
    private FirebaseRecyclerOptions<Model> options;
    private FirebaseRecyclerAdapter<Model, FirebaseViewHold> adapter;
    private DatabaseReference databaseReference;
    private EditText mSearchField;
    private ImageButton mSearchBtn;



    @Override
    public void onStart() {
        super.onStart();

        adapter.startListening();
    }

    @Override
    public void onStop() {
        super.onStop();
        adapter.stopListening();
    }

    private HomeViewModel homeViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        homeViewModel =
                ViewModelProviders.of(this).get(HomeViewModel.class);
        View root = inflater.inflate(R.layout.fragment_home, container, false);
        mSearchField = (EditText) root.findViewById(R.id.search_field);//native actual code ca-app-pub-5015873143206788/3082578626
        mSearchBtn = (ImageButton) root.findViewById(R.id.search_btn);
        recyclerView = root.findViewById(R.id.recyclerview);

        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        arrayList = new ArrayList<Model>();
        databaseReference = FirebaseDatabase.getInstance().getReference().child("Model").child("Events");
        databaseReference.keepSynced(true);
        options = new FirebaseRecyclerOptions.Builder<Model>().setQuery(databaseReference, Model.class).build();


        mSearchBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String searchText = mSearchField.getText().toString();
                firebaseUserSearch(searchText);

            }
        });
        adapter = new FirebaseRecyclerAdapter<Model, FirebaseViewHold>(options) {
            @Override
            protected void onBindViewHolder(@NonNull FirebaseViewHold firebaseViewHolder, int i, @NonNull Model model) {


                firebaseViewHolder.setDetails(getContext(), model.getName(), model.getInterests(), model.getSkills(), model.getPhonenumber(), model.getAbout(), model.getCity(), model.getCountry(), model.getEmail());

                firebaseViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //Cardview on click activity

                        String url = "http://wa.me/" + model.getPhonenumber();

                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setData(Uri.parse(url));
                        startActivity(i);

                    }
                });
            }

            @NonNull
            @Override
            public FirebaseViewHold onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                return new FirebaseViewHold(LayoutInflater.from(getContext()).inflate(R.layout.row_events, parent, false));
            }
        };

        recyclerView.setAdapter(adapter);

        return root;
    }
    //Search by skill query
    private void firebaseSkillSearch(String searchText) {

        Query firebaseSearchQuery = databaseReference.orderByChild("skills").startAt(searchText).endAt(searchText+ "\uf8ff");

        options = new FirebaseRecyclerOptions.Builder<Model>().setQuery(firebaseSearchQuery, Model.class).build();
        adapter = new FirebaseRecyclerAdapter<Model, FirebaseViewHold>(options) {
            @Override
            protected void onBindViewHolder(@NonNull FirebaseViewHold firebaseViewHolder, int i, @NonNull Model model) {

                firebaseViewHolder.setDetails(getContext(), model.getName(), model.getInterests(), model.getSkills(), model.getPhonenumber(), model.getAbout(), model.getCity(), model.getCountry(), model.getEmail());
                firebaseViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //Cardview on click activity


                        String url = "http://wa.me/" +model.getPhonenumber();

                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setData(Uri.parse(url));

                        i.putExtra(Intent.EXTRA_TEXT, "Hi, from conecta");
                        startActivity(i);
                    }
                });
            }

            @NonNull
            @Override
            public FirebaseViewHold onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                return new FirebaseViewHold(LayoutInflater.from(getContext()).inflate(R.layout.row_events, parent, false));
            }
        };

        recyclerView.setAdapter(adapter);
        adapter.startListening();
    }

//Search by city query

    private void firebaseCitySearch(String searchText) {
        Query firebaseSearchQuery = databaseReference.orderByChild("about").startAt(searchText).endAt(searchText+ "\uf8ff");

        options = new FirebaseRecyclerOptions.Builder<Model>().setQuery(firebaseSearchQuery, Model.class).build();

        adapter = new FirebaseRecyclerAdapter<Model, FirebaseViewHold>(options) {
            @Override
            protected void onBindViewHolder(@NonNull FirebaseViewHold firebaseViewHolder, int i, @NonNull Model model) {


                firebaseViewHolder.setDetails(getContext(), model.getName(), model.getInterests(), model.getSkills(), model.getPhonenumber(), model.getAbout(), model.getCity(), model.getCountry(), model.getEmail());
                firebaseViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //Cardview on click activity


                        String url = "http://wa.me/" +model.getPhonenumber();

                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setData(Uri.parse(url));
                        startActivity(i);

                    }
                });

            }

            @NonNull
            @Override
            public FirebaseViewHold onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                return new FirebaseViewHold(LayoutInflater.from(getContext()).inflate(R.layout.row_events, parent, false));
            }
        };

        recyclerView.setAdapter(adapter);
        adapter.startListening();



    }



    //Search by user name query

    private void firebaseUserSearch(String searchText) {

        Query firebaseSearchQuery = databaseReference.orderByChild("name").startAt(searchText).endAt(searchText+ "\uf8ff");

        options = new FirebaseRecyclerOptions.Builder<Model>().setQuery(firebaseSearchQuery, Model.class).build();


        adapter = new FirebaseRecyclerAdapter<Model, FirebaseViewHold>(options) {
            @Override
            protected void onBindViewHolder(@NonNull FirebaseViewHold firebaseViewHolder, int i, @NonNull Model model) {


                firebaseViewHolder.setDetails(getContext(), model.getName(), model.getInterests(), model.getSkills(), model.getPhonenumber(), model.getAbout(), model.getCity(), model.getCountry(), model.getEmail());

                firebaseViewHolder.itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //Cardview on click activity



                        String url = "http://wa.me/" +model.getPhonenumber();

                        Intent i = new Intent(Intent.ACTION_VIEW);
                        i.setData(Uri.parse(url));
                        startActivity(i);

                    }
                });
            }

            @NonNull
            @Override
            public FirebaseViewHold onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
                return new FirebaseViewHold(LayoutInflater.from(getContext()).inflate(R.layout.row_events, parent, false));
            }
        };

        recyclerView.setAdapter(adapter);
        adapter.startListening();

    }

}

