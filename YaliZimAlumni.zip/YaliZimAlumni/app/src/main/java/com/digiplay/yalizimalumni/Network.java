package com.digiplay.yalizimalumni;

public class Network {

private String type,imageUrl,description;


    public String phonenumber, businessname,email;




    public String getBusinessname() {
        return businessname;
    }

    public void setBusinessname(String businessname) {
        this.businessname = businessname;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getImageUrl() {
        return imageUrl;
    }


    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getDescription() {
        return description;
    }



    public void setDescription(String description) {
        this.description = description;
    }

    public Network(String type, String imageUrl, String description, String phonenumber,String businessname, String email) {

        this.type = type;
        this.imageUrl = imageUrl;
        this.description = description;
        this.businessname = businessname;
        this.email = email;
        this.phonenumber = phonenumber;

    }
    public Network(){


    }

}
