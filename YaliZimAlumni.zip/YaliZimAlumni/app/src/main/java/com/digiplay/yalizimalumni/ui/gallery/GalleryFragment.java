package com.digiplay.yalizimalumni.ui.gallery;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

import com.digiplay.yalizimalumni.Main2Activity;
import com.digiplay.yalizimalumni.Model;
import com.digiplay.yalizimalumni.R;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.io.IOException;

import static android.app.Activity.RESULT_OK;

public class GalleryFragment extends Fragment {


    EditText name, interests, skills, phonenumber, about, city, country, email;
    Button buttonpost, upload ,buttondelete,buttonupdate;
    private ImageView upload_pic;
    ProgressDialog progressDialog ;

    FirebaseDatabase database;
    DatabaseReference ref;
    Model model;

    private Uri filepath;
    private final int PICK_IMAGE_REQUEST =1;

    private GalleryViewModel galleryViewModel;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        galleryViewModel =
                ViewModelProviders.of(this).get(GalleryViewModel.class);
        View root = inflater.inflate(R.layout.fragment_gallery, container, false);

        progressDialog = new ProgressDialog(getContext());

        name = (EditText) root.findViewById(R.id.name);
        phonenumber = (EditText) root.findViewById(R.id.phonenumber);
        skills = (EditText) root.findViewById(R.id.skills);
        about = (EditText) root.findViewById(R.id.about);
        interests = (EditText) root.findViewById(R.id.interests);
        city = (EditText) root.findViewById(R.id.city);
        country = (EditText) root.findViewById(R.id.country);
        email = (EditText) root.findViewById(R.id.email);
        buttonupdate = (Button) root.findViewById(R.id.buttonupdate);
        buttondelete = (Button) root.findViewById(R.id.buttondelete);
        buttonpost = (Button) root.findViewById(R.id.buttonpost);
        upload = (Button) root.findViewById(R.id.upload);
        upload_pic = (ImageView) root.findViewById(R.id.upload_pic);

        database = FirebaseDatabase.getInstance();
        ref = database.getReference("Model");
        model=new Model();


        upload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                chooseImage();
            }
        });

        buttonpost.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                uploadimage();
                addPost();

            }
        });

        buttonupdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updatePost();
            }
        });

        buttondelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                deletePost();
            }
        });
        return root;
    }

    private void deletePost() {


        if (TextUtils.isEmpty(phonenumber.getText().toString()))
        {
            phonenumber.setError("Please enter your phone number to verify your profile.");
            return;
        }


        String key =  phonenumber.getText().toString();
        ref.child("Profile").child(key).removeValue();
        Toast.makeText(getContext(), "Profile Deleted, Sorry to see you go :(", Toast.LENGTH_LONG).show();


    }


    private void uploadimage() {

    }

    private void addPost() {

        getValue();
    }

    private void getValue(){

        model.setName(name.getText().toString());
        model.setAbout(about.getText().toString());
        model.setCity(city.getText().toString());
        model.setCountry(country.getText().toString());
        model.setEmail(email.getText().toString());
        model.setPhonenumber(phonenumber.getText().toString());
        model.setInterests(interests.getText().toString());
        model.setSkills(skills.getText().toString());

        if (TextUtils.isEmpty(name.getText().toString()))
        {
            name.setError("Field cannot be Empty");
            return;
        }
        else if (TextUtils.isEmpty(phonenumber.getText().toString()))
        {
            phonenumber.setError("Field cannot be Empty");
            return;
        }
        else if (TextUtils.isEmpty(about.getText().toString()))
        {
            about.setError("Field cannot be Empty");
            return;
        }

        else if (TextUtils.isEmpty(city.getText().toString()))
        {
            city.setError("Field cannot be Empty");
            return;
        }

        else if (TextUtils.isEmpty(country.getText().toString()))
        {
            country.setError("Field cannot be Empty");
            return;
        }

        else if (TextUtils.isEmpty(email.getText().toString()))
        {
            email.setError("Field cannot be Empty");
            return;
        }

        else if (TextUtils.isEmpty(interests.getText().toString()))
        {
            interests.setError("Field cannot be Empty");
            return;
        }
        else if (TextUtils.isEmpty(skills.getText().toString()))
        {
            skills.setError("Field cannot be Empty");
            return;
        } else



            progressDialog.setTitle("Adding your event...");
        progressDialog.show();

        String key = phonenumber.getText().toString();
        ref.child("Events").child(key).setValue(model);
        progressDialog.dismiss();

        Toast.makeText(getContext(), "Event Added Successfully but Image not uploaded, Upload Feature is disabled.", Toast.LENGTH_LONG).show();



        Intent DriverIntent = new Intent(getContext(), Main2Activity.class);
        startActivity(DriverIntent);
// Intent go back to Browse packages



    }


    private void updatePost() {
        model.setName(name.getText().toString());
        model.setAbout(about.getText().toString());
        model.setCity(city.getText().toString());
        model.setCountry(country.getText().toString());
        model.setEmail(email.getText().toString());
        model.setPhonenumber(phonenumber.getText().toString());
        model.setInterests(interests.getText().toString());
        model.setSkills(skills.getText().toString());


        if (TextUtils.isEmpty(phonenumber.getText().toString()))
        {
            phonenumber.setError("Field cannot be Empty");
            Toast.makeText(getContext(), "Please enter Phone Number", Toast.LENGTH_SHORT).show();
            return;
        }


        String key =  phonenumber.getText().toString();
        ref.child("Events").child(key).setValue(model);
        Toast.makeText(getContext(), "Event Details Updated.", Toast.LENGTH_LONG).show();

    }

    public void addPost(View view) {

        addPost();
    }


    private void chooseImage() {

        Intent intent2 = new Intent();
        intent2.setType("image/*");
        intent2.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(intent2,PICK_IMAGE_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK
                && data != null && data.getData() != null) {

            filepath = data.getData();

            try {
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), filepath);
                upload_pic.setImageBitmap(bitmap);
            } catch (IOException e) {

                e.printStackTrace();
            }

        }
    }


}

