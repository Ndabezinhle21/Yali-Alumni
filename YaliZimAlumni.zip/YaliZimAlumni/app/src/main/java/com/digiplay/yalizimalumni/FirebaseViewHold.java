package com.digiplay.yalizimalumni;

import android.content.Context;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class FirebaseViewHold extends RecyclerView.ViewHolder {

    public TextView name, interests, skills, phonenumber, about, city, country, email;


        View mView;

        public FirebaseViewHold(@NonNull View itemView) {
            super(itemView);

            mView = itemView;

        }
        public void setDetails(Context ctx, String name, String interests, String skills, String phonenumber, String about, String city, String country, String email){


            TextView mInterestView = mView.findViewById(R.id.interests);
            TextView mNameView= mView.findViewById(R.id.name);
            TextView mSkillsView = mView.findViewById(R.id.skills);
            TextView mAboutView= mView.findViewById(R.id.about);
            TextView mCityView= mView.findViewById(R.id.city);
            TextView mCountryView= mView.findViewById(R.id.country);
            TextView mEmailView= mView.findViewById(R.id.email);
            TextView mPhoneView= mView.findViewById(R.id.phonenumber);

            mInterestView.setText(interests);
            mNameView.setText(name);
            mSkillsView.setText(skills);
            mAboutView.setText(about);
            mCityView.setText(city);
            mCountryView.setText(country);
            mEmailView.setText(email);
            mPhoneView.setText(phonenumber);
        }

    public void setNews(Context context, String name, String phonenumber, String about) {

        TextView mPhoneView= mView.findViewById(R.id.phonenumber);
        TextView mNameView= mView.findViewById(R.id.name);
        TextView mAboutView= mView.findViewById(R.id.about);

        mNameView.setText(name);
        mPhoneView.setText(phonenumber);
        mAboutView.setText(about);
    }
}